from django.contrib import admin
from .models import Patient, Detection
# Register your models here.


admin.site.register(Patient)
admin.site.register(Detection)