from django import forms
from .models import Patient


class PatientCreateForm(forms.Form):


    name = forms.CharField()
    nationalID = forms.CharField()
    description = forms.CharField(widget=forms.Textarea)
    image = forms.ImageField(required=True)


class PatientUpdateForm(forms.ModelForm):

    class Meta:
        model = Patient
        fields = ('name', 'nationalID', 'description', 'image')