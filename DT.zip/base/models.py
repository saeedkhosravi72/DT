from django.db import models

# Create your models here.


class Patient(models.Model):

    def __str__(self):
        return self.name

    name = models.CharField(max_length=50)
    nationalID = models.CharField(max_length=20)
    image = models.ImageField(upload_to='static/uploads/')
    description = models.CharField(max_length=500)
    created_at = models.DateTimeField(auto_now_add=True)



class Detection(models.Model):

    def __str__(self):
        return self.patient.name

    patient = models.ForeignKey(Patient, on_delete=models.CASCADE)
    dImage = models.ImageField(upload_to='static/uploads/detections/')