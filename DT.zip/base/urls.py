from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('search/', views.search, name='patient_search'),
    path('create/', views.patient_create, name='patient_create'),
    path('delete/<int:id>/', views.patient_delete, name='patient_delete'),
    path('update/<int:id>/', views.patient_update, name='patient_update'),
    path('detect/<int:id>/', views.patient_detect, name='patient_detect'),
    path('detect/', views.detect_list, name='detect_list'),
    path('detect/<int:id>', views.detect_view, name='detect_view'),
    path('detect/delete/<int:id>', views.detect_delete, name='detect_delete')

]
